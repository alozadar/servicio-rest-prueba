package com.ejercicio.casoPrueba.unitTest;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.ejercicio.casoPrueba.repository.PersonaRepository;
import com.ejercicio.casoPrueba.impl.PersonaServiceImpl;
import com.ejercicio.casoPrueba.entity.Persona;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class PersonaServiceMockTest {
	
	@Mock
	PersonaRepository personaRepository;
   
	@InjectMocks
	PersonaServiceImpl personaServiceImpl;
	
	@Test
    public void testRetrievePersonas() {
		List<Persona> personaList = new ArrayList<Persona>();
		Persona persona1 = new Persona ();
		persona1.setId(1L);
		persona1.setNombre("Nombre prueba 1");
		persona1.setSexo("Femenino");
		persona1.setNacionalidad("Mexicana");
		persona1.setFechaNacimiento("13/04/1998");
		persona1.setTelefono("5523354366");
		persona1.setEmail("correo1@test.com");
		personaList.add(persona1);
		Persona persona2 = new Persona ();
		persona2.setId(2L);
		persona2.setNombre("Nombre prueba 2");
		persona2.setSexo("Masculino");
		persona2.setNacionalidad("Italiana");
		persona2.setFechaNacimiento("12/11/1990");
		persona2.setTelefono("55756784366");
		persona2.setEmail("correo2@test.com");
		personaList.add(persona2);
		when(personaRepository.findAll()).thenReturn(personaList);
		
		List<Persona> result = personaServiceImpl.retrievePersonas();
		assertEquals(2, result.size());
    }

	@Test
	public void testGetPersona(){
		Persona persona = new Persona ();
		persona.setNombre("Nombre prueba 1");
		persona.setSexo("Femenino");
		persona.setNacionalidad("Mexicana");
		persona.setFechaNacimiento("13/04/1998");
		persona.setTelefono("5523354366");
		persona.setEmail("correo1@test.com");
		Optional<Persona> personaOpt = Optional.of(persona);
		when(personaRepository.findById(1L)).thenReturn(personaOpt);
		Persona result = personaServiceImpl.getPersona(1L);
		assertEquals("Nombre prueba 1", result.getNombre());
	}
	
	@Test
	public void testSavePersona(){
		Persona persona = new Persona ();
		persona.setId(1L);
		persona.setNombre("Nombre prueba 1");
		persona.setSexo("Femenino");
		persona.setNacionalidad("Mexicana");
		persona.setFechaNacimiento("13/04/1998");
		persona.setTelefono("5523354366");
		persona.setEmail("correo1@test.com");
		personaServiceImpl.savePersona(persona);
		verify(personaRepository, times(1)).save(persona);
	}
	
	@Test
	public void testDeletePersona(){
		Persona persona = new Persona ();
		persona.setId(1L);
		persona.setNombre("Nombre prueba 1");
		persona.setSexo("Femenino");
		persona.setNacionalidad("Mexicana");
		persona.setFechaNacimiento("13/04/1998");
		persona.setTelefono("5523354366");
		persona.setEmail("correo1@test.com");
		personaServiceImpl.deletePersona(persona.getId());
		verify(personaRepository, times(1)).deleteById(persona.getId());
	}
}
