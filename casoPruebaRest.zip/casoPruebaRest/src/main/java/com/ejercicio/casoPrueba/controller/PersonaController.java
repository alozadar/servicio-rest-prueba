package com.ejercicio.casoPrueba.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ejercicio.casoPrueba.entity.Persona;
import com.ejercicio.casoPrueba.service.PersonaService;

/**
 * @author Aurora Lozada
 *
 */
@RestController
public class PersonaController {

	@Autowired
	private PersonaService personaService;

	public void setPersonaService(PersonaService personaService) {
		this.personaService = personaService;
	}

	@GetMapping("/personas")
	public List<Persona> getPersonas() {
		List<Persona> personas = personaService.retrievePersonas();
		return personas;
	}

	@GetMapping("/personas/{personaId}")
	public Persona getPersona(@PathVariable(name = "personaId") Long personaId) {
		return personaService.getPersona(personaId);
	}

	@PostMapping("/personas")
	public void savePersona(Persona persona) {
		personaService.savePersona(persona);
		System.out.println("Persona guardada exitosamente.");
	}

	@DeleteMapping("/personas/{personaId}")
	public void deletePersona(@PathVariable(name = "personaId") Long personaId) {
		personaService.deletePersona(personaId);
		System.out.println("Persona eliminada exitosamente.");
	}

	@PutMapping("/personas/{personaId}")
	public void updatePersona(@RequestBody Persona persona, @PathVariable(name = "personaId") Long personaId) {
		Persona pers = personaService.getPersona(personaId);
		if (pers != null) {
			personaService.updatePersona(persona);
		}

	}

}
