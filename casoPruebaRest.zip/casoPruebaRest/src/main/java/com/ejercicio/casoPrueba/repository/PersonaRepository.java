package com.ejercicio.casoPrueba.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ejercicio.casoPrueba.entity.Persona; 

/**
 * @author Aurora Lozada
 *
 */
@Repository
public interface PersonaRepository extends JpaRepository<Persona,Long> {

}
