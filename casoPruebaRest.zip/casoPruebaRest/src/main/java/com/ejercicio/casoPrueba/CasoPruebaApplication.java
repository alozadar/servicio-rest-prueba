package com.ejercicio.casoPrueba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableSwagger2 
@ComponentScan(basePackages = "com.ejercicio")
public class CasoPruebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasoPruebaApplication.class, args);
	}

}
