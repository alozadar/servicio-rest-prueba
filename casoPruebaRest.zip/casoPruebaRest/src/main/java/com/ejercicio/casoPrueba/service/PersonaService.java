package com.ejercicio.casoPrueba.service;

import java.util.List;

import com.ejercicio.casoPrueba.entity.Persona;

/**
 * @author Aurora Lozada
 *
 */

public interface PersonaService {
	
	public List<Persona> retrievePersonas();
	  
	 public Persona getPersona(Long personaId);
	  
	 public void savePersona(Persona persona);
	  
	 public void deletePersona(Long personaId);
	  
	 public void updatePersona(Persona persona);
}
