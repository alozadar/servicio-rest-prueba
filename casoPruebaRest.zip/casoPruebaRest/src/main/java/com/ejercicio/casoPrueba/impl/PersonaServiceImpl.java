package com.ejercicio.casoPrueba.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ejercicio.casoPrueba.entity.Persona;
import com.ejercicio.casoPrueba.service.PersonaService;
import com.ejercicio.casoPrueba.repository.PersonaRepository;

/**
 * @author Aurora Lozada
 *
 */
@Service
public class PersonaServiceImpl implements PersonaService {

	@Autowired
	private PersonaRepository personaRepository;

	public void setPersonaRepository(PersonaRepository personaRepository) {
		this.personaRepository = personaRepository;
	}

	public List<Persona> retrievePersonas() {
		List<Persona> personas = personaRepository.findAll();
		return personas;
	}

	public Persona getPersona(Long personaId) {
		Optional<Persona> optPers = personaRepository.findById(personaId);
		return optPers.get();
	}

	public void savePersona(Persona persona) {
		personaRepository.save(persona);
	}

	public void deletePersona(Long personaId) {
		personaRepository.deleteById(personaId);
	}

	public void updatePersona(Persona persona) {
		personaRepository.save(persona);

	}

}
